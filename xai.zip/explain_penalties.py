#!/usr/bin/env python3
"""
explain_penalties.py - MACRO-level explanation: how penalty weights (lambda) moved during training.

READ-ONLY on existing results. No training, no evaluation, no model forward pass.
Needs only: json, numpy, matplotlib. (torch only if --mark-best is passed.)

Input : <runs-dir>/<name>_s<seed>/train_log.jsonl   (written by `lastmile_rl.py train`)
Output: <out-dir>/lambda_over_updates.png / .pdf / .csv
        <out-dir>/excess_over_updates.png
        <out-dir>/run_summary.csv

What each train_log.jsonl line holds (verified against cmd_train in lastmile_rl.py):
  update            : 1..U
  lambda            : [n_phases][3] seconds-per-unit-cost for (zone_exit, zone_reentry, far_jump),
                      value AFTER the dual-ascent step of this update (so it is the lambda used by update+1)
  train_excess      : {cost: mean over batch of (episode cost - driver budget), summed over phases}
  val (every eval-every updates only): {ratio_vs_nn, gap_vs_driver, mean_excess{...}, feasible}
Lambda at "update 0" (= --lambda-init) is NOT in the log; --mark-best reads it from best.pt args.

BC logs (bc_*_s*/train_log.jsonl) have no 'lambda' key and are skipped automatically.
Frozen-penalty runs have constant lambda: reported in run_summary.csv, not plotted unless --include-frozen.
"""
import argparse
import csv
import json
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

COSTS = ("zone_exit", "zone_reentry", "far_jump")   # same order as COST_NAMES in lastmile_rl.py


def read_log(path: Path):
    recs = []
    for ln in path.read_text(encoding="utf-8").splitlines():
        if ln.strip():
            r = json.loads(ln)
            if "lambda" in r:
                recs.append(r)
    return recs


def ckpt_info(run_dir: Path):
    """Optional, read-only: step of best.pt and lambda_init. Never writes."""
    try:
        import torch
        ck = torch.load(run_dir / "best.pt", map_location="cpu", weights_only=False)
        a = ck.get("args", {})
        return {"best_step": int(ck["step"]), "lambda_init": a.get("lambda_init"),
                "penalty": a.get("penalty"), "active": a.get("active")}
    except Exception as e:
        print(f"  (no ckpt info for {run_dir.name}: {type(e).__name__})")
        return None


def roll(x, w):
    if w <= 1 or len(x) < w:
        return np.asarray(x, float)
    k = np.ones(w) / w
    return np.convolve(np.pad(x, (w // 2, w - 1 - w // 2), mode="edge"), k, mode="valid")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs-dir", required=True, help="e.g. /content/drive/MyDrive/lastmile_work/runs_full")
    ap.add_argument("--out-dir", required=True, help="NEW folder, e.g. .../explain_full/macro")
    ap.add_argument("--runs", default="", help="comma list of run dir names (default: all with a lambda log)")
    ap.add_argument("--include-frozen", action="store_true", help="also plot constant-lambda runs")
    ap.add_argument("--mark-best", action="store_true", help="read best.pt (read-only, needs torch) to mark selected update")
    ap.add_argument("--smooth", type=int, default=10, help="rolling window for train_excess")
    a = ap.parse_args()

    runs_dir, out = Path(a.runs_dir), Path(a.out_dir)
    want = {s for s in a.runs.split(",") if s}
    logs = sorted(p for p in runs_dir.glob("*/train_log.jsonl") if not want or p.parent.name in want)
    if not logs:
        raise SystemExit(f"no train_log.jsonl under {runs_dir}")
    out.mkdir(parents=True, exist_ok=True)

    runs = {}
    for p in logs:
        recs = read_log(p)
        if not recs:
            print(f"skip {p.parent.name}: no 'lambda' records (behaviour-cloning log?)")
            continue
        lam = np.array([r["lambda"] for r in recs], float)          # [U, P, K]
        upd = np.array([r["update"] for r in recs])
        order = np.argsort(upd, kind="stable")
        runs[p.parent.name] = {
            "dir": p.parent, "upd": upd[order], "lam": lam[order], "recs": [recs[i] for i in order],
            "varies": bool(np.abs(lam - lam[0]).max() > 1e-12),
        }

    # ---- summary table (always, includes frozen runs) ----
    with open(out / "run_summary.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["run", "updates_logged", "phases", "lambda_varies", "cost", "phase",
                    "lambda_first_logged", "lambda_last_logged", "lambda_max"])
        for name, r in runs.items():
            for k, c in enumerate(COSTS):
                for ph in range(r["lam"].shape[1]):
                    s = r["lam"][:, ph, k]
                    w.writerow([name, len(s), r["lam"].shape[1], r["varies"], c, ph + 1,
                                f"{s[0]:.4g}", f"{s[-1]:.4g}", f"{s.max():.4g}"])
    frozen = [n for n, r in runs.items() if not r["varies"]]
    if frozen:
        print("constant lambda (frozen penalty) - not plotted:", ", ".join(frozen))

    plot = {n: r for n, r in runs.items() if r["varies"] or a.include_frozen}
    if not plot:
        raise SystemExit("no run with changing lambda; use --include-frozen to plot constant ones")

    info = {n: (ckpt_info(r["dir"]) if a.mark_best else None) for n, r in plot.items()}

    # ---- tidy CSV ----
    with open(out / "lambda_over_updates.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["run", "update", "phase", "cost", "lambda_after_update"])
        for n, r in plot.items():
            for i, u in enumerate(r["upd"]):
                for ph in range(r["lam"].shape[1]):
                    for k, c in enumerate(COSTS):
                        w.writerow([n, int(u), ph + 1, c, f"{r['lam'][i, ph, k]:.6g}"])

    # ---- figure 1: lambda ----
    R = len(plot)
    fig, axs = plt.subplots(R, 3, figsize=(12, 2.6 * R), squeeze=False, sharex="col")
    for i, (n, r) in enumerate(plot.items()):
        P = r["lam"].shape[1]
        for k, c in enumerate(COSTS):
            ax = axs[i, k]
            for ph in range(P):
                lab = "all stops" if P == 1 else f"phase {ph + 1}/{P}"
                ax.plot(r["upd"], r["lam"][:, ph, k], label=lab, lw=1.4)
            inf = info[n]
            if inf and inf["best_step"] is not None:
                ax.axvline(inf["best_step"], color="k", ls=":", lw=1)
            if i == 0:
                ax.set_title(c)
            if k == 0:
                ax.set_ylabel(f"{n}\nlambda (s / unit cost)")
            if i == R - 1:
                ax.set_xlabel("PPO update")
            ax.grid(alpha=0.3)
            if k == 2:
                ax.legend(fontsize=7, loc="best")
    note = "lambda logged after each dual-ascent step (= value used by next update); update-0 value not logged"
    if a.mark_best:
        note += "; dotted line = update of best.pt"
    fig.suptitle(note, fontsize=8, y=0.995)
    fig.tight_layout()
    for ext in ("png", "pdf"):
        fig.savefig(out / f"lambda_over_updates.{ext}", dpi=150)
    plt.close(fig)

    # ---- figure 2: budget excess (what drives dual ascent) ----
    fig, axs = plt.subplots(R, 1, figsize=(8, 2.6 * R), squeeze=False, sharex=True)
    for i, (n, r) in enumerate(plot.items()):
        ax = axs[i, 0]
        for c in COSTS:
            y = np.array([rec["train_excess"][c] for rec in r["recs"]], float)
            ax.plot(r["upd"], roll(y, a.smooth), label=f"train {c} (roll {a.smooth})", lw=1.2)
            vx = [rec["update"] for rec in r["recs"] if "val" in rec]
            vy = [rec["val"]["mean_excess"][c] for rec in r["recs"] if "val" in rec]
            ax.scatter(vx, vy, s=10, marker="x")
        ax.axhline(0, color="k", lw=0.8)
        ax.set_ylabel(f"{n}\nexcess vs driver budget")
        ax.grid(alpha=0.3)
        if i == 0:
            ax.legend(fontsize=7, ncol=3)
    axs[-1, 0].set_xlabel("PPO update  (x = validation mean_excess, only every eval-every updates)")
    fig.tight_layout()
    fig.savefig(out / "excess_over_updates.png", dpi=150)
    plt.close(fig)
    print(f"wrote -> {out}")


if __name__ == "__main__":
    main()
