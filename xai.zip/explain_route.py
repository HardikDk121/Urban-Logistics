#!/usr/bin/env python3
"""
explain_route.py - ROUTE-level comparison for one route across existing eval_*.json files.

Part A (always, JSON only; needs numpy): reads eval_*.json 'records' and prints, for the selected route,
    time vs driver/nn/nn_2opt/ortools, amazon_score, stored behaviour costs vs driver budget.
Part B (--replay, needs lastmile_rl.py + --cache-dir; NO checkpoint, NO model forward pass):
    replays tours through the environment (run_episode mode="follow") to get the behaviour of the FINAL stored
    sequence, the driver, and the baselines (nn, nn_2opt, ortools from cache baselines.json): totals, per-phase
    costs, zone switches, and a list of cost events (which stop pair caused a zone_exit / re-entry / far_jump).

Why Part B exists: in cmd_evaluate, record["costs"] come from the raw policy rollout (ep.costs) while
record["sequence"] / ["time"] / ["amazon_score"] are computed AFTER best-of-N selection and intra-zone 2-opt.
"costs" can therefore differ from the behaviour of "sequence" (certainly for far_jump; the code docstring
claims exit/re-entry are preserved by the 2-opt). Part B shows the difference instead of assuming it.

Outputs go to --out-dir (NEW folder). Nothing in runs_*/ cache_*/ report_*/ is modified.

Run as a fresh process; with --replay lastmile_rl.py is imported before torch (OR-Tools load order).

Example:
  !python /content/explain_route.py \
     --evals "/content/drive/MyDrive/lastmile_work/runs_full/*/eval_test.json" \
     --cache-dir /content/drive/MyDrive/lastmile_work/cache_full \
     --auto worst_reentry --replay \
     --out-dir /content/drive/MyDrive/lastmile_work/explain_full/route
"""
import argparse
import csv
import glob
import json
import os
import sys
from pathlib import Path

import numpy as np

COSTS = ("zone_exit", "zone_reentry", "far_jump")
BASE = ("driver", "nn", "nn_2opt", "ortools")


def load(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def find(e, rid):
    return next((r for r in e["records"] if r["route"] == rid), None)


def choose_route(first, a):
    recs = first["records"]
    if a.route_id:
        return a.route_id
    key = {
        "worst_reentry": lambda r: r["costs"]["zone_reentry"] - r["driver_costs"]["zone_reentry"],
        "worst_exit": lambda r: r["costs"]["zone_exit"] - r["driver_costs"]["zone_exit"],
        "slowest_vs_driver": lambda r: r["time"] / r["baselines"]["driver"],
    }.get(a.auto)
    if key:
        return max(recs, key=key)["route"]
    return recs[a.route_index]["route"]


def fmt(x, w=8, p=3):
    return f"{x:>{w}.{p}f}" if isinstance(x, (int, float, np.floating)) else f"{str(x):>{w}}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--evals", nargs="+", required=True, help="glob(s) of eval_*.json (same split/perturb)")
    ap.add_argument("--route-id", default="")
    ap.add_argument("--route-index", type=int, default=0, help="index into records of the first eval file")
    ap.add_argument("--auto", choices=("", "worst_reentry", "worst_exit", "slowest_vs_driver"), default="",
                    help="pick the route from the first eval file instead of by index")
    ap.add_argument("--replay", action="store_true", help="Part B: environment replay (needs --cache-dir)")
    ap.add_argument("--cache-dir", default="")
    ap.add_argument("--out-dir", required=True)
    a = ap.parse_args()

    paths = sorted({p for pat in a.evals for p in glob.glob(pat)})
    if not paths:
        raise SystemExit("no eval files matched")
    evals = [(p, load(p)) for p in paths]
    rid = choose_route(evals[0][1], a)
    out = Path(a.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    print(f"route {rid}   ({len(evals)} eval files)\n")

    # ------------------------------------------------------------------ Part A
    print("PART A - from eval JSON only (costs = raw rollout costs as stored; time/amazon = final sequence)")
    h = (f"{'label':<22}{'seed':>5}{'split':>6}{'pert':>6}{'stops':>6}{'min':>8}"
         f"{'/driver':>9}{'/nn':>8}{'/nn2opt':>9}{'/ortools':>9}{'amazon':>8}")
    print(h)
    rowsA = []
    for p, e in evals:
        r = find(e, rid)
        if r is None:
            print(f"{e['label']:<22} (route not in {p})")
            continue
        b = r["baselines"]
        ratios = [r["time"] / b[k] if k in b else float("nan") for k in BASE[:]]
        print(f"{e['label']:<22}{e['seed']:>5}{e['split']:>6}{e['perturb']:>6}{r['stops']:>6}{r['time']/60:>8.1f}"
              f"{ratios[0]:>9.3f}{ratios[1]:>8.3f}{ratios[2]:>9.3f}{ratios[3]:>9.3f}{r['amazon_score']:>8.4f}")
        row = {"label": e["label"], "seed": e["seed"], "split": e["split"], "perturb": e["perturb"], "mode_field": e["mode"],
               "stops": r["stops"], "time_min": r["time"] / 60, "latency_ms": r["latency_ms"], "amazon_score": r["amazon_score"]}
        row.update({f"time_over_{k}": v for k, v in zip(BASE, ratios)})
        row.update({f"baseline_amazon_{k}": v for k, v in r["baseline_amazon"].items()})
        for c in COSTS:
            row[f"stored_{c}"], row[f"budget_{c}"] = r["costs"][c], r["driver_costs"][c]
            row[f"ok_{c}"] = r["costs"][c] <= r["driver_costs"][c] + 1e-9
        rowsA.append(row)
    print(f"\n{'label':<22}" + "".join(f"{c + ' (got/budget)':>26}" for c in COSTS))
    for row in rowsA:
        print(f"{row['label']:<22}" + "".join(
            f"{row['stored_' + c]:>14.2f}/{row['budget_' + c]:<6.2f}{'ok' if row['ok_' + c] else 'OVER':>4}" for c in COSTS))
    if rowsA:
        with open(out / f"route_{rid}_summary.csv", "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(dict.fromkeys(k for r in rowsA for k in r)))
            w.writeheader()
            w.writerows(rowsA)
    print("\nNOT in eval JSON: per-step data, per-phase costs/budgets (driver_costs is summed over phases), "
          "costs of baseline tours, zone ids / stop ids ('sequence' holds cache node indices), sample_n / zone-2opt flags "
          "('mode' says 'greedy' for any --ckpt run even when best-of-N sampling was used).")

    if not a.replay:
        print(f"\nwrote -> {out}\n(use --replay --cache-dir ... for Part B)")
        return

    # ------------------------------------------------------------------ Part B
    if not a.cache_dir:
        raise SystemExit("--replay needs --cache-dir")
    sys.path.insert(0, os.environ.get("LASTMILE_DIR", "/content"))
    import lastmile_rl as L          # noqa: E402  must precede torch
    import torch                     # noqa: E402

    dev = torch.device("cpu")
    stores = {}

    def store_for(cfg):
        k = tuple(sorted(L.asdict(cfg).items()))
        if k not in stores:
            stores[k] = L.RouteStore(a.cache_dir, cfg, dev)
        return stores[k]

    with np.load(Path(a.cache_dir) / "routes" / f"{rid}.npz") as z:
        node_ids = [str(s) for s in z["node_ids"]]

    print("\nPART B - environment replay of tours (no model). costs recomputed from the tour itself.")
    tours, rows, events, phase_rows = [], [], [], []
    first_cfg = None
    for p, e in evals:
        r = find(e, rid)
        if r is None:
            continue
        cfg = L.EnvConfig(**e["env_cfg"])
        first_cfg = first_cfg or cfg
        st = store_for(cfg)
        route = st.get(rid)
        P = cfg.n_phases
        names = [("driver", route.driver.tolist())] + [(k, st.baselines[rid][k]["seq"]) for k in BASE[1:] if k in st.baselines[rid]]
        names += [(f"{e['label']}[s{e['seed']}] final", r["sequence"])]
        for nm, seq in names:
            if nm in ("driver",) + BASE[1:] and any(t[0] == nm for t in tours):
                continue                      # baselines are identical across eval files
            ep = L.run_episode(route, cfg, "follow", follow=[int(x) for x in seq])
            tot = ep.costs.sum(0)
            zs = route.zone[np.array(seq)]
            switches = int(sum(1 for i in range(1, len(zs)) if zs[i] != zs[i - 1] and zs[i] >= 0 and zs[i - 1] >= 0))
            tours.append((nm, seq))
            rows.append({"tour": nm, "eval_label": e["label"], "seed": e["seed"], "time_min_nominal_T": ep.total_time / 60,
                         **{f"{c}": float(tot[k]) for k, c in enumerate(COSTS)},
                         **{f"budget_{c}": float(route.budget.sum(0)[k]) for k, c in enumerate(COSTS)},
                         "zone_switches": switches, "n_zones_visited": int(len(set(zs[zs >= 0]))),
                         "stored_time_min": r["time"] / 60 if "final" in nm else "",
                         **({f"stored_{c}": r["costs"][c] for c in COSTS} if "final" in nm else {})})
            if P > 1 and ("final" in nm or nm == "driver"):
                cp = ep.costs_by_phase(P)
                for ph in range(P):
                    phase_rows.append({"tour": nm, "phase": ph + 1, **{c: float(cp[ph, k]) for k, c in enumerate(COSTS)},
                                       **{f"budget_{c}": float(route.budget[ph, k]) for k, c in enumerate(COSTS)}})
            for t in range(len(ep.actions)):
                c = ep.costs[t]
                if c.any():
                    events.append({"tour": nm, "step": t, "from": node_ids[int(ep.cur[t])], "to": node_ids[int(ep.actions[t])],
                                   "zone_from": int(route.zone[int(ep.cur[t])]), "zone_to": int(route.zone[int(ep.actions[t])]),
                                   "travel_s": float(ep.travel[t]), "phase": int(ep.phases[t]) + 1,
                                   **{f"cost_{n}": float(c[k]) for k, n in enumerate(COSTS)}})
            if "final" in nm and e["perturb"] == 0 and abs(ep.total_time - r["time"]) > 1e-3:
                print(f"  WARNING {nm}: replay time {ep.total_time:.1f}s != stored {r['time']:.1f}s")

    hdr = f"{'tour':<34}{'min':>8}{'exit':>8}{'reent':>7}{'far':>5}{'switch':>8}{'zones':>6}   stored costs (raw rollout)"
    print(hdr)
    for rw in rows:
        s = ("" if rw["stored_time_min"] == "" else
             f"exit={rw['stored_zone_exit']:.2f} reent={rw['stored_zone_reentry']:.0f} far={rw['stored_far_jump']:.0f}")
        print(f"{rw['tour']:<34}{rw['time_min_nominal_T']:>8.1f}{rw['zone_exit']:>8.2f}{rw['zone_reentry']:>7.0f}"
              f"{rw['far_jump']:>5.0f}{rw['zone_switches']:>8}{rw['n_zones_visited']:>6}   {s}")
    drv = next(rw for rw in rows if rw["tour"] == "driver")
    print(f"driver budget row = driver replay (exit={drv['zone_exit']:.2f}, reentry={drv['zone_reentry']:.0f}, far={drv['far_jump']:.0f}). "
          f"far_jump threshold {first_cfg.farjump_regret_s:.0f}s. 'time' here uses nominal T (perturbed files store perturbed time).")
    if phase_rows:
        print("\nper-phase costs (n_phases>1):")
        for pr in phase_rows:
            print(f"  {pr['tour']:<34} phase {pr['phase']}: " + " ".join(f"{c}={pr[c]:.2f}/{pr['budget_' + c]:.2f}" for c in COSTS))

    for name, data in (("replay_summary", rows), ("replay_phase", phase_rows), ("replay_events", events)):
        if data:
            with open(out / f"route_{rid}_{name}.csv", "w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=list(dict.fromkeys(k for r in data for k in r)))
                w.writeheader()
                w.writerows(data)
    print(f"\nwrote -> {out}  (route_{rid}_summary / replay_summary / replay_phase / replay_events .csv)")


if __name__ == "__main__":
    main()
