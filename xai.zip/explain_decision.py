#!/usr/bin/env python3
"""
explain_decision.py - DECISION-level explanation for ONE route of a trained checkpoint.

INFERENCE ONLY. Loads a checkpoint read-only, runs one greedy rollout, recomputes the actor logits of
every step with Policy.evaluate (same function PPO/BC use; no gradients, no optimizer, no saving of weights).
Writes only into --out-dir (a NEW folder). Does not touch runs_*/, cache_*/, report_*/.

Run as a fresh process (!python ...), never %run / import inside the notebook kernel:
lastmile_rl.py must be imported BEFORE torch (OR-Tools load order).

What it prints for the chosen step t:
  * chosen stop + critic value + lambda (from the checkpoint) used to weigh immediate costs
  * a table of the valid candidates (action mask), sorted by actor logit, with
      logit, softmax prob,
      the 6 dynamic features the actor actually receives (dynamic_features() in lastmile_rl.py):
        t_cand/tau          = T[cur,cand] / tau                       (code: row / tau)
        extra_vs_nearest    = max(T[cur,cand] - nearest_unvisited, 0)/tau   (code: np.maximum(row-nearest,0)/tau)
        same_zone           = cand in current zone (0/1)
        reentry             = cand's zone was left earlier with stops remaining (0/1)   (env.open_exited)
        zone_rem            = unvisited fraction of cand's zone                (docstring: zone_remaining_ratio)
        zone_exit_d         = min time from cand's zone to another unvisited zone / tau (docstring: zone_min_exit_dist)
      (names for the first four are MY labels - the code has no string names for them),
      seconds T[cur,cand],
      immediate env costs if this candidate were chosen (exact: env.step on a copy): exit, reentry, far,
      pen_s = sum_k lambda[phase,k]*cost_k  (the penalty seconds PPO subtracts from the reward at this step).
NOT included, because it does not exist in the model: per-feature contributions. The actor is a 2-layer MLP over
[GCN+stats embedding (20 dims, learned), 6 dynamic features, LSTM route context], so logit is NOT a sum of columns.
Treat the feature columns as inputs shown next to the score, not as a causal decomposition.

Example (Colab):
  !python /content/explain_decision.py \
     --cache-dir /content/drive/MyDrive/lastmile_work/cache_full \
     --ckpt /content/drive/MyDrive/lastmile_work/runs_full/frozen_topk_s0/best.pt \
     --split test --route-index 0 --list-steps \
     --out-dir /content/drive/MyDrive/lastmile_work/explain_full/decision
"""
import argparse
import copy
import csv
import os
import sys
from pathlib import Path

sys.path.insert(0, os.environ.get("LASTMILE_DIR", "/content"))   # folder holding lastmile_rl.py
import lastmile_rl as L          # noqa: E402  (must come before torch)
import numpy as np               # noqa: E402
import torch                     # noqa: E402

FEATS = ["t_cand/tau", "extra_vs_nearest", "same_zone", "reentry", "zone_rem", "zone_exit_d"]


def clone_env(env):
    e = copy.copy(env)                       # route / zone_size shared (never mutated by step)
    e.visited, e.zone_left = env.visited.copy(), env.zone_left.copy()
    e.open_exited, e.seq = set(env.open_exited), list(env.seq)
    return e


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cache-dir", required=True)
    ap.add_argument("--ckpt", required=True, help="best.pt or last.pt (opened read-only)")
    ap.add_argument("--split", default="test", choices=("train", "val", "test"))
    ap.add_argument("--route-id", default="", help="route id (as in eval_*.json 'route')")
    ap.add_argument("--route-index", type=int, default=0, help="index into the split if --route-id not given")
    ap.add_argument("--step", type=int, default=-1, help="decision step (0-based). default: first step where greedy != nearest valid stop")
    ap.add_argument("--top", type=int, default=8, help="rows to print (chosen stop always shown)")
    ap.add_argument("--list-steps", action="store_true", help="also print one line per step")
    ap.add_argument("--compare-eval", default="", help="optional eval_*.json: check greedy tour vs stored 'sequence'")
    ap.add_argument("--device", default="cpu", help="cpu = deterministic (as in the script docs)")
    ap.add_argument("--out-dir", required=True)
    a = ap.parse_args()

    dev = torch.device(a.device)
    L.set_seed(0)
    ck = torch.load(a.ckpt, map_location=dev, weights_only=False)            # read-only
    cfg = L.EnvConfig(**ck["env_cfg"])
    policy = L.Policy().to(dev).eval()
    policy.load_state_dict(ck["policy"])
    lam = np.array(ck["lam"], float)                                          # [P, K]
    run_name = f"{ck['args'].get('name', 'run')}_s{ck['args'].get('seed', '?')}"
    print(f"ckpt: {a.ckpt}\n  run={run_name} update={ck['step']} penalty={ck['args'].get('penalty')} env={ck['env_cfg']}")
    print(f"  lambda[phase][zone_exit,zone_reentry,far_jump] = {np.round(lam, 2).tolist()}")

    store = L.RouteStore(a.cache_dir, cfg, dev)
    ids = store.split(a.split)
    rid = a.route_id or ids[a.route_index]
    if rid not in ids:
        raise SystemExit(f"route {rid} not in split '{a.split}'")
    route = store.get(rid)
    with np.load(Path(a.cache_dir) / "routes" / f"{rid}.npz") as z:
        node_ids = [str(s) for s in z["node_ids"]]

    ep = L.run_episode(route, cfg, "greedy", policy)                          # inference only
    with torch.no_grad():
        logits, values = policy.evaluate(route, ep)                           # [S,N], [S]
    logits, values = logits.cpu().numpy(), values.cpu().numpy()
    S, N = logits.shape
    mism = int((logits.argmax(1) != ep.actions).sum())
    lp = torch.log_softmax(torch.tensor(logits), -1).numpy()[np.arange(S), ep.actions]
    print(f"route {rid}: {S} stops, greedy time {ep.total_time/60:.1f} min | check: argmax!=action at {mism}/{S} steps, "
          f"max|logp diff|={np.abs(lp - ep.logp).max():.2e}")
    if mism:
        print("  WARNING: recomputed logits disagree with rollout at some steps (float nondeterminism?). Use --device cpu.")

    # cost / penalty preview per step, using the environment itself (exact, no re-implementation)
    env = L.RouteEnv(route, cfg)
    rows_by_step, summary = [], []
    for t in range(S):
        assert env.cur == int(ep.cur[t]), "replay diverged"
        valid = np.flatnonzero(ep.mask[t])
        ph = env.phase()
        recs = []
        for j in valid:
            tt, c, _ = clone_env(env).step(int(j))
            recs.append((int(j), float(tt), c, float((c * lam[ph]).sum())))
        rows_by_step.append((ph, recs))
        row_t = route.T[env.cur, valid]
        nearest_valid = int(valid[np.argmin(row_t)])
        probs = np.exp(lp[t])
        summary.append({"step": t, "phase": ph + 1, "cur": node_ids[env.cur], "chosen": node_ids[int(ep.actions[t])],
                        "n_valid": int(valid.size), "chosen_is_nearest_valid": int(ep.actions[t]) == nearest_valid,
                        "p_chosen": float(probs), "critic_value": float(values[t])})
        env.step(int(ep.actions[t]))

    if a.step >= 0:
        t = a.step
    else:
        t = next((s["step"] for s in summary if not s["chosen_is_nearest_valid"]), 0)
    if not 0 <= t < S:
        raise SystemExit(f"--step must be in [0,{S-1}]")

    if a.list_steps:
        print("\nstep ph  n_valid  p_chosen  nearest?  cur -> chosen")
        for s in summary:
            print(f"{s['step']:>4} {s['phase']:>2} {s['n_valid']:>8} {s['p_chosen']:>9.3f}  {str(s['chosen_is_nearest_valid']):>8}  "
                  f"{s['cur']} -> {s['chosen']}")

    ph, recs = rows_by_step[t]
    valid = [r[0] for r in recs]
    lg = logits[t][valid]
    pr = np.exp(lg - lg.max()); pr /= pr.sum()
    order = np.argsort(-lg)
    chosen = int(ep.actions[t])
    show = list(order[: a.top])
    cpos = valid.index(chosen)
    if cpos not in show:
        show.append(cpos)
    print(f"\nDECISION step {t} (phase {ph+1}/{cfg.n_phases}): at {node_ids[int(ep.cur[t])]}, "
          f"{len(valid)} valid candidates, critic V={values[t]:.3f}")
    print(f"CHOSEN (greedy = max logit): node {chosen} / stop {node_ids[chosen]}   p={pr[cpos]:.3f}")
    hdr = (f"{'rank':>4} {'node':>5} {'stop_id':>10} {'logit':>8} {'prob':>6} | " + " ".join(f"{f:>16}" for f in FEATS)
           + f" | {'sec':>6} {'exit':>5} {'reent':>5} {'far':>4} {'pen_s':>7}  zone")
    print(hdr)
    out_rows = []
    for i in show:
        j, tt, c, pen = recs[i]
        d = ep.dyn[t, j]
        rank = int(np.where(order == i)[0][0]) + 1
        mark = " <== chosen" if j == chosen else ""
        print(f"{rank:>4} {j:>5} {node_ids[j]:>10} {lg[i]:>8.3f} {pr[i]:>6.3f} | " + " ".join(f"{x:>16.3f}" for x in d)
              + f" | {tt:>6.0f} {c[0]:>5.2f} {c[1]:>5.0f} {c[2]:>4.0f} {pen:>7.1f}  {int(route.zone[j])}{mark}")
        out_rows.append([rank, j, node_ids[j], f"{lg[i]:.5f}", f"{pr[i]:.5f}", *[f"{x:.5f}" for x in d],
                         f"{tt:.1f}", *[f"{x:.4f}" for x in c], f"{pen:.2f}", int(route.zone[j]), j == chosen])
    print("(logit = actor output; masked/invalid stops have logit -1e9 and are not listed. pen_s uses lambda stored in the ckpt.)")

    out = Path(a.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    stem = f"{run_name}_{a.split}_{rid}"
    with open(out / f"{stem}_step{t}.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["rank", "node", "stop_id", "logit", "prob", *FEATS, "travel_s", "cost_exit", "cost_reentry",
                    "cost_far", "penalty_s", "zone", "chosen"])
        w.writerows(out_rows)
    with open(out / f"{stem}_steps.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(summary[0]))
        w.writeheader()
        w.writerows(summary)
    print(f"wrote -> {out}/{stem}_step{t}.csv and {stem}_steps.csv")

    if a.compare_eval:
        import json
        rec = next((r for r in json.load(open(a.compare_eval, encoding="utf-8"))["records"] if r["route"] == rid), None)
        if rec is None:
            print(f"--compare-eval: route {rid} not in {a.compare_eval}")
        else:
            raw = list(map(int, ep.sequence))
            opt = L.intra_zone_two_opt(raw, route.zone, route.T)
            st = rec["sequence"]
            div = next((k for k, (x, y) in enumerate(zip(raw, st)) if x != y), None)
            print(f"\nvs stored eval record: greedy raw == stored: {raw == st} | greedy+intra-zone-2opt == stored: {opt == st}"
                  f" | first position where raw greedy differs: {div}")
            if raw != st and opt != st:
                print("  stored tour was NOT produced by plain greedy (pipeline evaluates trained runs with --sample-n 8 + 2-opt);"
                      " this trace explains the greedy policy, not the stored tour.")


if __name__ == "__main__":
    main()
